import { send, readJson, kvGet, verifyToken, planThresholds, reqId, rateLimit } from '../_lib.js';
export default async function handler(req, res) {
  const requestId = reqId(req);
  if (req.method !== 'POST') return send(res, 405, { ok: false, error: 'method-not-allowed', requestId });
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
  const rl = await rateLimit(`verify:${ip}`, 120, 60);
  if (!rl.ok) return send(res, 429, { ok: false, error: 'rate-limited', requestId });
  const body = await readJson(req);
  const payload = verifyToken(body?.token || '');
  if (!payload) return send(res, 403, { ok: false, error: 'invalid-token', requestId });
  const meta = await kvGet(`publickey:${payload.publicKey}`);
  if (!meta || meta.secret !== body?.secretKey) return send(res, 403, { ok: false, error: 'invalid-secret', requestId });
  const th = planThresholds(meta.plan);
  let decision = 'ALLOW';
  if (payload.risk >= th.blockAt) decision = 'BLOCK';
  else if (payload.risk >= th.challengeAt) decision = 'CHALLENGE';
  send(res, 200, { ok: true, decision, risk: payload.risk, plan: meta.plan, requestId });
}
